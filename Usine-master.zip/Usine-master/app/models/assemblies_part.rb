class AssembliesPart < ApplicationRecord
end
